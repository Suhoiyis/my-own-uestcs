cd lab1; make clean; cd ..
cd lab2; make clean; cd ..
cd lab3; make clean; cd ..
cd lab4; make clean; cd ..
cd lab5; make clean; cd ..
cd lab6; make clean; cd ..
cd lab7; make clean; cd ..
cd lab8; make clean; cd ..
