#ifndef GENLLVM_H
#define GENLLVM_H

#include "ast.h"

int genllvm(ast* root);

#endif
